import { staffResolvers } from "./resolvers";
import { staffTypeDef } from "./typeDefs";




export { staffResolvers, staffTypeDef };
