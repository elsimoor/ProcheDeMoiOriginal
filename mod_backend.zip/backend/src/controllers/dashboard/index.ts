import { dashboardTypeDef } from './typeDefs';
import { dashboardResolvers } from './resolvers';

export  {
  dashboardTypeDef,
  dashboardResolvers,
};
