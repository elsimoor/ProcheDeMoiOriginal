import { privatisationResolvers } from "./resolvers";
import { privatisationTypeDef } from "./typeDefs";




export { privatisationResolvers, privatisationTypeDef };
