import { serviceResolvers } from "./resolvers";
import { serviceTypeDef } from "./typeDefs";




export { serviceResolvers, serviceTypeDef };
